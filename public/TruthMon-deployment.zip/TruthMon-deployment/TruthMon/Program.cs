﻿using dotenv.net;
using Microsoft.Playwright;
using SendGrid;
using SendGrid.Helpers.Mail;
using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Net.Mail;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using Twilio;
using Twilio.Base;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

public static class PostNotifier
{
    private static readonly HttpClient _http = new HttpClient
    {
        BaseAddress = new Uri("https://api.openai.com/v1/")
    };

    private static readonly JsonSerializerOptions _json =
        new(JsonSerializerDefaults.Web)
        {
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        };

    private static string SendGridTemplate => Environment.GetEnvironmentVariable("SENDGRID_TEMPLATE_ID") ?? "d-3e6a5f49032643649274d514e70a884c";
    private static string SendGridApiKey => Environment.GetEnvironmentVariable("SENDGRID_API_KEY") ?? "";
    private static string SendGridFrom => Environment.GetEnvironmentVariable("SENDGRID_FROM_EMAIL") ?? "";
    private static string SendGridTo => Environment.GetEnvironmentVariable("SENDGRID_TO_EMAIL") ?? "";

    private static string OpenAiKey => Environment.GetEnvironmentVariable("OPENAI_API_KEY") ?? "";
    private static string OpenAiModel => Environment.GetEnvironmentVariable("OPENAI_MODEL") ?? "gpt-4.1-mini";

    private static string TwilioSid => Environment.GetEnvironmentVariable("TWILIO_ACCOUNT_SID") ?? "";
    private static string TwilioToken => Environment.GetEnvironmentVariable("TWILIO_AUTH_TOKEN") ?? "";
    private static string TwilioFrom => Environment.GetEnvironmentVariable("TWILIO_FROM") ?? "";
    private static string AlertTo => Environment.GetEnvironmentVariable("ALERT_TO") ?? "";

    /// <summary>
    /// Classifies the post text using OpenAI Responses API with a strict JSON schema.
    /// Returns "positive", "neutral", or "negative".
    /// </summary>
    public static async Task<string> ClassifyAsync(string postText, string extraPrompt = "")
    {
        if (string.IsNullOrWhiteSpace(OpenAiKey))
            throw new InvalidOperationException("OPENAI_API_KEY not set.");

        _http.DefaultRequestHeaders.Authorization =
            new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", OpenAiKey);

        var system = "You are a precise classifier. Only use the JSON schema provided. " +
                     "Rate overall sentiment toward markets/financial outlook as positive, neutral, or negative.";

        var user = string.IsNullOrWhiteSpace(extraPrompt)
            ? $"Classify this text:\n\n{postText}"
            : $"{extraPrompt.Trim()}\n\n---\nText:\n{postText}";

        // Build the JSON Schema
        var schema = new JsonObject
        {
            ["type"] = "object",
            ["properties"] = new JsonObject
            {
                ["label"] = new JsonObject
                {
                    ["type"] = "string",
                    ["description"] = "Overall sentiment label.",
                    ["enum"] = new JsonArray("positive", "neutral", "negative")
                }
            },
            ["required"] = new JsonArray("label"),
            ["additionalProperties"] = false
        };

        // Build the request body (Responses API)
        var bodyNode = new JsonObject
        {
            ["model"] = OpenAiModel, // e.g., "gpt-5.1-mini"
            ["input"] = JsonSerializer.SerializeToNode(new object[]
            {
        new { role = "system", content = system },
        new { role = "user",  content = user   }
            }),
            ["max_output_tokens"] = 512,
            ["text"] = new JsonObject
            {
                ["format"] = new JsonObject
                {
                    ["type"] = "json_schema",
                    ["name"] = "SentimentLabel",
                    // >>> Required field here:
                    ["schema"] = schema
                }
            }
        };

        using var req = new HttpRequestMessage(HttpMethod.Post, "responses")
        {
            Content = new StringContent(bodyNode.ToJsonString(), System.Text.Encoding.UTF8, "application/json")
        };

        using var resp = await _http.SendAsync(req);
        var payload = await resp.Content.ReadAsStringAsync();
        if (!resp.IsSuccessStatusCode)
            throw new InvalidOperationException($"OpenAI error {resp.StatusCode}: {payload}");

        using var doc = JsonDocument.Parse(payload);
        var root = doc.RootElement;

        // 1) Ensure we actually completed
        if (root.TryGetProperty("status", out var stEl) &&
            stEl.ValueKind == JsonValueKind.String &&
            stEl.GetString() != "completed")
        {
            string reason = "(unknown)";
            if (root.TryGetProperty("incomplete_details", out var inc) &&
                inc.ValueKind == JsonValueKind.Object &&
                inc.TryGetProperty("reason", out var r) &&
                r.ValueKind == JsonValueKind.String)
            {
                reason = r.GetString() ?? reason;
            }
            throw new InvalidOperationException($"OpenAI response incomplete: {reason}. Raw: {payload}");
        }

        string? jsonPayload = null;

        // 2) Some responses include a convenience string
        if (root.TryGetProperty("output_text", out var outTextEl) &&
            outTextEl.ValueKind == JsonValueKind.String)
        {
            jsonPayload = outTextEl.GetString();
        }

        // 3) Otherwise, walk output[] and find the message chunk with output_text
        if (string.IsNullOrWhiteSpace(jsonPayload) &&
            root.TryGetProperty("output", out var outputEl) &&
            outputEl.ValueKind == JsonValueKind.Array)
        {
            for (int i = 0; i < outputEl.GetArrayLength() && string.IsNullOrWhiteSpace(jsonPayload); i++)
            {
                var item = outputEl[i];

                // Prefer the message item
                if (item.TryGetProperty("type", out var typeEl) &&
                    typeEl.ValueKind == JsonValueKind.String &&
                    typeEl.GetString() == "message" &&
                    item.TryGetProperty("content", out var contentEl) &&
                    contentEl.ValueKind == JsonValueKind.Array)
                {
                    for (int ci = 0; ci < contentEl.GetArrayLength(); ci++)
                    {
                        var chunk = contentEl[ci];
                        if (chunk.TryGetProperty("type", out var tEl) &&
                            tEl.ValueKind == JsonValueKind.String &&
                            tEl.GetString() == "output_text" &&
                            chunk.TryGetProperty("text", out var textEl) &&
                            textEl.ValueKind == JsonValueKind.String)
                        {
                            jsonPayload = textEl.GetString();
                            break;
                        }

                        // Fallback: some chunks may just expose "text"
                        if (chunk.TryGetProperty("text", out var textEl2) &&
                            textEl2.ValueKind == JsonValueKind.String)
                        {
                            jsonPayload = textEl2.GetString();
                            break;
                        }
                    }
                }
            }
        }

        if (string.IsNullOrWhiteSpace(jsonPayload))
            throw new InvalidOperationException("OpenAI response missing output text. Raw: " + payload);

        // 4) Parse {"label":"positive|neutral|negative"}
        var result = JsonSerializer.Deserialize<SentimentDto>(jsonPayload!, _json)
                     ?? throw new InvalidOperationException("Failed to parse sentiment JSON: " + jsonPayload);

        return result.Label;
    }

    public static async Task<string> SendEmailAsync(string postText, string postUrl)
    {
        if (string.IsNullOrWhiteSpace(SendGridApiKey))
            throw new InvalidOperationException("SENDGRID_API_KEY not set.");
        if (string.IsNullOrWhiteSpace(SendGridFrom) || string.IsNullOrWhiteSpace(SendGridTo))
            throw new InvalidOperationException("SENDGRID_FROM_EMAIL or SENDGRID_TO_EMAIL not set.");

        var client = new SendGridClient(SendGridApiKey);

        var from = new EmailAddress(SendGridFrom);
        var to = new EmailAddress(SendGridTo);

        var msg = new SendGridMessage
        {
            From = from,
            TemplateId = SendGridTemplate
        };
        msg.AddTo(to);

        // Template data — "Data" is exactly what you asked for
        msg.SetTemplateData(new
        {
            data = postText   // full text of the positive post
        });

        var response = await client.SendEmailAsync(msg);
        var responseBody = await response.Body.ReadAsStringAsync();
        Console.WriteLine($"[SendGrid] Status: {(int)response.StatusCode} {response.StatusCode}");
        Console.WriteLine($"[SendGrid] Body: {responseBody}");
        return response.StatusCode.ToString();
    }


    /// <summary>
    /// Sends an SMS via Twilio with the given message body.
    /// </summary>
    public static string SendSms(string body)
    {
        if (string.IsNullOrWhiteSpace(TwilioSid) || string.IsNullOrWhiteSpace(TwilioToken))
            throw new InvalidOperationException("Twilio credentials not set.");
        if (string.IsNullOrWhiteSpace(TwilioFrom) || string.IsNullOrWhiteSpace(AlertTo))
            throw new InvalidOperationException("TWILIO_FROM or ALERT_TO not set.");

        TwilioClient.Init(TwilioSid, TwilioToken);

        var msg = MessageResource.Create(
            to: new PhoneNumber(AlertTo),
            from: new PhoneNumber(TwilioFrom),
            body: body);

        return msg.Sid;
    }

    private sealed record SentimentDto([property: JsonPropertyName("label")] string Label);
}

record PostRecord(string Id, string Url, string Username, string Text, DateTimeOffset? PublishedAt);

sealed class MastodonStatus
{
    [JsonPropertyName("id")] public string? Id { get; set; }
    [JsonPropertyName("url")] public string? Url { get; set; }
    [JsonPropertyName("content")] public string? ContentHtml { get; set; }
    [JsonPropertyName("created_at")] public string? CreatedAt { get; set; }
}

record MastodonAccount([property: JsonPropertyName("id")] string Id);

public class PostJs
{
    [JsonPropertyName("id")] public string? Id { get; set; }
    [JsonPropertyName("url")] public string? Url { get; set; }
    [JsonPropertyName("text")] public string? Text { get; set; }
    [JsonPropertyName("dt")] public string? Dt { get; set; }
}

public class SeenStore
{
    private readonly string _path;
    private readonly HashSet<string> _ids = new(StringComparer.Ordinal);

    public SeenStore(string path)
    {
        _path = path;
        Directory.CreateDirectory(Path.GetDirectoryName(_path)!);
        if (File.Exists(_path))
        {
            try
            {
                var existing = JsonSerializer.Deserialize<HashSet<string>>(File.ReadAllText(_path));
                if (existing != null) foreach (var id in existing) _ids.Add(id);
            }
            catch { /* ignore */ }
        }
    }

    public bool IsNew(string id) => !_ids.Contains(id);

    public void Mark(params string[] ids)
    {
        foreach (var id in ids) _ids.Add(id);
        File.WriteAllText(_path, JsonSerializer.Serialize(_ids, new JsonSerializerOptions { WriteIndented = true }));
    }
}

public record class Config
{
    public string[] Usernames { get; init; } = Array.Empty<string>();
    public int IntervalSeconds { get; init; } = 75;
    public bool Headless { get; init; } = true;
    public string? WebhookUrl { get; init; }
    public string? Proxy { get; init; } // e.g. http://user:pass@host:port
    public int PerProfileMaxNew { get; init; } = 5;

    public static Config FromEnv()
    {
        string env(string k, string? d = null) => Environment.GetEnvironmentVariable(k) ?? d ?? "";
        return new Config
        {
            // Usernames = env("USERNAMES").Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries),
            Usernames = new string[] { "realDonaldTrump" }, // hardcoded default; override via args or env
            IntervalSeconds = int.TryParse(env("INTERVAL_SEC", "45"), out var s) ? Math.Max(10, s) : 45,
            Headless = !string.Equals(env("HEADFUL"), "true", StringComparison.OrdinalIgnoreCase),
            WebhookUrl = string.IsNullOrWhiteSpace(env("WEBHOOK_URL")) ? null : env("WEBHOOK_URL"),
            Proxy = string.IsNullOrWhiteSpace(env("PROXY")) ? null : env("PROXY"),
            PerProfileMaxNew = int.TryParse(env("PER_PROFILE_MAX_NEW", "5"), out var m) ? Math.Max(1, m) : 5
        };
    }
}

public class Program
{
    static async Task Main(string[] args)
    {
        DotEnv.Load(); // will load .env from the current working directory by default
        var cfg = Config.FromEnv();
        if (cfg.Usernames.Length == 0 && args.Length > 0) cfg = cfg with { Usernames = args };
        if (cfg.Usernames.Length == 0)
        {
            Console.WriteLine("Set env USERNAMES=\"realDonaldTrump,anotherUser\" or pass usernames as args.");
            return;
        }

        var seen = new SeenStore(Path.Combine("data", "seen.json"));

        using var playwright = await Playwright.CreateAsync();
        var launchOpts = new BrowserTypeLaunchOptions { Headless = cfg.Headless };

        if (!string.IsNullOrWhiteSpace(cfg.Proxy))
            launchOpts.Proxy = new Proxy { Server = cfg.Proxy };

        await using var browser = await playwright.Chromium.LaunchAsync(launchOpts);

        // One context across runs keeps cookies; rotate contexts if you need isolation
        var context = await browser.NewContextAsync(new BrowserNewContextOptions
        {
            // Lower risk of bot detection
            UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
                        "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
        });

        Console.WriteLine($"Monitoring: {string.Join(", ", cfg.Usernames.Select(u => "@" + u))} " +
                          $"every {cfg.IntervalSeconds}s  (headless: {cfg.Headless}, proxy: {cfg.Proxy ?? "none"})");

        // Create a page per profile to avoid reloading all tabs on every loop
        var pages = new Dictionary<string, IPage>(StringComparer.OrdinalIgnoreCase);
        foreach (var u in cfg.Usernames)
        {
            var p = await context.NewPageAsync();
            p.Dialog += async (_, dlg) => await dlg.DismissAsync();
            pages[u] = p;
        }

        while (true)
        {
            foreach (var username in cfg.Usernames)
            {
                try
                {
                    /* ====
                     * ==== V1
                     * ====
                    var page = pages[username];
                    var url = $"https://truthsocial.com/@{username}";
                    await page.GotoAsync(url, new PageGotoOptions { WaitUntil = WaitUntilState.NetworkIdle, Timeout = 45000 });

                    // give the app time and trigger lazy loads
                    await SettleContentAsync(page);

                    await DismissTruthAdModal(page);

                    await page.EvaluateAsync("() => window.scrollTo(0, document.body.scrollHeight)"); // trigger virtualization
                    await page.WaitForTimeoutAsync(1500);                                   // let items render
                    await page.EvaluateAsync("() => window.scrollTo(0, 0)");                // optional: back to top

                    // (optional) wait for at least *something* we expect
                    try
                    {
                        // Wait for any article OR any post-like anchor; pick whichever appears first
                        // If neither shows in 8s, we’ll dump debug info
                        await page.WaitForSelectorAsync("article, a[href*='/posts/'], a[href*='/status']", new() { Timeout = 8000 });
                    }
                    catch { }


                    var posts = await ExtractPosts(page, username);
                    // If zero, emit a very loud debug dump so we can see what's wrong:
                    if (posts.Count == 0)
                    {
                        Console.WriteLine($"[WARN] Zero posts detected on @{username}. Dumping debug artifacts…");
                        await DebugDumpAsync(page, $"noposts_{username}");

                        // As a last-ditch attempt, try a *super simple* fallback extractor
                        posts = await FallbackExtractPosts(page, username);
                        Console.WriteLine($"[INFO] Fallback extractor found {posts.Count} candidate(s).");
                    }
                    */

                    // V2
                    using var http = new HttpClient();
                    http.DefaultRequestHeaders.Add("Accept", "application/json");
                    http.DefaultRequestHeaders.Add("User-Agent", "Mozilla/5.0 (compatible; PostExtractorBot/1.0)");

                    var url = "https://truthsocial.com/api/v1/accounts/107780257626128497/statuses?limit=40&exclude_replies=true&exclude_reblogs=true";
                    var page = pages[username];
                    await page.GotoAsync(url, new PageGotoOptions { WaitUntil = WaitUntilState.NetworkIdle, Timeout = 45000 });
                    var jsonText = await page.EvaluateAsync<string>(
                        """
                        async (url) => {
                          const res = await fetch(url, {
                            credentials: 'include',
                            headers: { 'Accept': 'application/json' }
                          });
                          if (!res.ok) throw new Error(`HTTP ${res.status}`);
                          return await res.text();
                        }
                        """,
                        url
                    );

                    var posts = ExtractPostsV2(jsonText, username);

                    // newest first
                    var latest = posts
                        .OrderByDescending(p => p.PublishedAt ?? DateTimeOffset.MinValue)
                        .ThenByDescending(p => p.Id)
                        .ToList();

                    int newCount = 0;
                    foreach (var post in latest)
                    {
                        if (string.IsNullOrEmpty(post.Text)) continue;
                        if (!seen.IsNew(post.Id)) continue;

                        seen.Mark(post.Id);
                        newCount++;

                        Console.WriteLine($"\n[{DateTimeOffset.Now:u}] @{post.Username} NEW POST");
                        Console.WriteLine($"ID: {post.Id}");
                        Console.WriteLine($"URL: {post.Url}");
                        if (post.PublishedAt is not null) Console.WriteLine($"Time: {post.PublishedAt:u}");
                        Console.WriteLine($"Text: {(string.IsNullOrWhiteSpace(post.Text) ? "(no text)" : Trim(post.Text, 800))}");

                        // Optional: your own “what counts as positive” context
                        var prompt = "Consider positivity in terms of stock market risk-on tone or bullish macro sentiment, or anything related to tariffs.";

                        var label = await PostNotifier.ClassifyAsync(post.Text, prompt);

                        if (string.Equals(label, "positive", StringComparison.OrdinalIgnoreCase))
                        {
                            // var sid = PostNotifier.SendSms($"Positive post detected.\n{post.Url}");
                            // Console.WriteLine($"SMS sent. SID={sid}");
                            var status = await PostNotifier.SendEmailAsync(post.Text, post.Url ?? string.Empty);
                            Console.WriteLine($"SendGrid email sent. Status={status}");
                        }
                        else
                        {
                            Console.WriteLine($"Not positive ({label}). No SMS sent.");
                        }

                        if (cfg.WebhookUrl is not null)
                        {
                            try { await SendWebhook(cfg.WebhookUrl, post); }
                            catch (Exception ex) { Console.WriteLine("Webhook error: " + ex.Message); }
                        }

                        if (newCount >= cfg.PerProfileMaxNew) break; // avoid floods on first run
                    }
                }
                catch (TimeoutException)
                {
                    Console.WriteLine($"[{DateTimeOffset.Now:u}] Timeout loading @{username} — will retry.");
                }
                catch (PlaywrightException ex)
                {
                    Console.WriteLine($"[{DateTimeOffset.Now:u}] Playwright error @{username}: {ex.Message}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[{DateTimeOffset.Now:u}] Error @{username}: {ex}");
                }
            }

            await Task.Delay(TimeSpan.FromSeconds(cfg.IntervalSeconds));
        }
    }

    static string Trim(string s, int max) => s.Length <= max ? s : s[..max] + "…";

    // Utility: HTML -> plain text
    private static string HtmlToText(string? html)
    {
        if (string.IsNullOrWhiteSpace(html)) return string.Empty;

        // remove tags
        var noTags = Regex.Replace(html, "<\\s*br\\s*/?>", "\n", RegexOptions.IgnoreCase);
        noTags = Regex.Replace(noTags, "<.*?>", " ");

        // decode HTML entities
        var decoded = WebUtility.HtmlDecode(noTags);

        // collapse whitespace, keep single newlines
        var normalized = Regex.Replace(decoded, "[ \\t\\f\\r]+", " ");
        normalized = Regex.Replace(normalized, "\\n{3,}", "\n\n").Trim();

        return normalized;
    }

    // 🔹 New method: parse posts directly from Mastodon JSON text
    static List<PostRecord> ExtractPostsV2(string mastodonJson, string username)
    {
        if (string.IsNullOrWhiteSpace(mastodonJson))
            return new List<PostRecord>();

        List<MastodonStatus>? items;
        try
        {
            items = JsonSerializer.Deserialize<List<MastodonStatus>>(
                mastodonJson,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true }
            );
        }
        catch
        {
            items = null;
        }

        if (items is null || items.Count == 0)
            return new List<PostRecord>();

        var results = new List<PostRecord>(items.Count);
        foreach (var s in items)
        {
            if (string.IsNullOrWhiteSpace(s?.Id)) continue;

            // url fallback if missing in payload
            var url = string.IsNullOrWhiteSpace(s.Url)
                ? $"https://truthsocial.com/@{username}/posts/{s.Id}"
                : s.Url!;

            DateTimeOffset? when = null;
            if (!string.IsNullOrWhiteSpace(s.CreatedAt) &&
                DateTimeOffset.TryParse(s.CreatedAt, out var parsed))
            {
                when = parsed.ToUniversalTime();
            }

            var text = HtmlToText(s.ContentHtml);

            results.Add(new PostRecord(
                Id: s.Id!,
                Url: url,
                Username: username,
                Text: text,
                PublishedAt: when
            ));
        }

        return results;
    }

    static async Task<List<PostRecord>> ExtractPosts(IPage page, string username)
    {
        var script = """
        (username) => {
          const out = [];

          // Strategy A: standard post cards
          const cards = Array.from(document.querySelectorAll('[data-testid="status"], .status'))
            .map(c => ({ root: c, idHost: c.querySelector('[data-id]') || c }));

          for (const { root, idHost } of cards) {
            const id = idHost?.getAttribute?.('data-id');
            if (!id) continue;

            const url = `https://truthsocial.com/@${username}/posts/${id}`;

            let text = '';
            const content = root.querySelector(
              '[data-testid="status-content"], .status__content, .status__content__text, [data-testid="content"], .prose, [role="paragraph"]'
            );
            if (content?.innerText?.trim()) {
              text = content.innerText.trim();
            } else {
              const blocks = Array.from(root.querySelectorAll('p, div'))
                .filter(n => {
                  const cls = (n.className || '').toString();
                  const skip = /(badge|toolbar|actions|menu|tabs|account|avatar|reactions|spoiler|media|embed|tooltip|dropdown)/i.test(cls);
                  const txt = (n.innerText || '').trim();
                  return !skip && txt.length > 0;
                })
                .map(n => n.innerText.trim());
              text = Array.from(new Set(blocks)).join('\n').trim();
            }

            let dt = null;
            const timeEl = root.querySelector('time[datetime]');
            if (timeEl?.getAttribute('datetime')) {
              dt = timeEl.getAttribute('datetime');
            } else {
              const link = root.querySelector('[role="link"][aria-label]');
              const aria = link?.getAttribute('aria-label') || '';
              const m = aria.match(/,\s*([A-Z][a-z]{2}\s+\d{1,2},\s+\d{1,2}:\d{2}\s+[AP]M)\s*,/);
              if (m) dt = m[1];
            }

            out.push({ id, url, text, dt });
          }

          // Strategy B (fallback): harvest permalinks like /posts/{id} anywhere on the page
          if (out.length === 0) {
            const links = Array.from(document.querySelectorAll('a[href*="/posts/"]'));
            for (const a of links) {
              const m = a.href.match(/\/posts\/(\d+)/);
              if (!m) continue;
              const id = m[1];
              const url = `https://truthsocial.com/@${username}/posts/${id}`;

              // Walk upward a bit to find nearby text
              let root = a.closest('[data-testid="status"], .status') || a.parentElement;
              let text = '';
              if (root) {
                const content = root.querySelector('[data-testid="status-content"], .status__content, .status__content__text');
                text = (content?.innerText || root.innerText || '').trim();
              }
              if (text.length > 3000) text = text.slice(0, 3000);

              let dt = null;
              const timeEl = root?.querySelector?.('time[datetime]');
              if (timeEl?.getAttribute?.('datetime')) dt = timeEl.getAttribute('datetime');

              out.push({ id, url, text, dt });
            }
          }

          return JSON.stringify(out);
        }
        """;

        var json = await page.EvaluateAsync<string>(script, username);
        if (string.IsNullOrWhiteSpace(json) || json[0] != '[') json = "[]";

        var raw = JsonSerializer.Deserialize<List<PostJs>>(json) ?? new();

        var results = new List<PostRecord>();
        foreach (var r in raw)
        {
            if (string.IsNullOrWhiteSpace(r.Id) || string.IsNullOrWhiteSpace(r.Url)) continue;

            DateTimeOffset? when = null;
            if (!string.IsNullOrWhiteSpace(r.Dt) && DateTimeOffset.TryParse(r.Dt, out var parsed))
                when = parsed;

            results.Add(new PostRecord(r.Id, r.Url, username, r.Text?.Trim() ?? "", when));
        }
        return results;
    }


    static async Task SendWebhook(string url, PostRecord post)
    {
        using var http = new HttpClient();
        var payload = new
        {
            id = post.Id,
            url = post.Url,
            username = post.Username,
            text = post.Text,
            publishedAt = post.PublishedAt?.UtcDateTime.ToString("o")
        };
        var json = JsonSerializer.Serialize(payload);
        using var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
        var resp = await http.PostAsync(url, content);
        resp.EnsureSuccessStatusCode();
    }

    static async Task DismissOverlays(IPage page)
    {
        // Try a few passes; some sites animate overlays in
        for (int pass = 0; pass < 3; pass++)
        {
            try
            {
                // Common close buttons inside modals/overlays
                var closeSelectors = new[]
                {
                "button[aria-label*='close' i]",
                "button:has-text('×')",
                "button:has-text('Close')",
                ".btn-close, .close, [data-action='close']",
                "[role='dialog'] button",
                "[aria-modal='true'] button"
            };

                // Any visible dialog/overlay containers
                var overlaySelectors = new[]
                {
                "[role='dialog']",
                "[aria-modal='true']",
                ".modal:visible,.overlay:visible,.backdrop:visible",
                "div[style*='z-index']:visible",
            };

                // Cookie banners (accept to clear)
                var cookieButtons = new[]
                {
                "button:has-text('Accept')",
                "button:has-text('I Accept')",
                "button:has-text('Agree')",
                "button:has-text('Got it')",
            };

                // 1) Try clicking cookie accept if present
                foreach (var sel in cookieButtons)
                {
                    var btn = page.Locator(sel);
                    if (await btn.IsVisibleAsync())
                    {
                        await btn.First.ClickAsync(new LocatorClickOptions { Trial = false });
                        await page.WaitForTimeoutAsync(200);
                    }
                }

                // 2) Try standard close buttons
                bool closed = false;
                foreach (var sel in closeSelectors)
                {
                    var close = page.Locator(sel);
                    if (await close.IsVisibleAsync())
                    {
                        await close.First.ClickAsync();
                        closed = true;
                        await page.WaitForTimeoutAsync(250);
                    }
                }
                if (closed) continue;

                // 3) ESC often dismisses promos
                await page.Keyboard.PressAsync("Escape");
                await page.WaitForTimeoutAsync(150);

                // 4) Click on backdrop/outside area (top-left corner)
                // If overlay absorbs clicks, try bottom-right too.
                await page.Mouse.ClickAsync(5, 5);
                await page.WaitForTimeoutAsync(150);

                // Use the ViewportSize property instead of an async call
                var vp = page.ViewportSize ?? new PageViewportSizeResult { Width = 1000, Height = 750 };
                await page.Mouse.ClickAsync(50, 50);
                // await page.Mouse.ClickAsync(vp.Width - 5, vp.Height - 5);
                await page.WaitForTimeoutAsync(150);

                // Try to click inside any visible iframe backdrop (best-effort)
                var frames = page.Frames;
                foreach (var f in frames)
                {
                    if (f == page.MainFrame) continue;
                    try
                    {
                        var closeInFrame = f.Locator("button[aria-label*='close' i], .btn-close, .close");
                        if (await closeInFrame.IsVisibleAsync())
                        {
                            await closeInFrame.First.ClickAsync();
                            await page.WaitForTimeoutAsync(150);
                        }
                    }
                    catch { }
                }

                // 5) As a last resort, remove visible high z-index overlays
                foreach (var sel in overlaySelectors)
                {
                    var loc = page.Locator(sel);
                    if (await loc.IsVisibleAsync())
                    {
                        // Remove top 3 matches (avoid being too destructive)
                        int count = Math.Min(await loc.CountAsync(), 3);
                        for (int i = 0; i < count; i++)
                        {
                            var handle = await loc.Nth(i).ElementHandleAsync();
                            if (handle is not null)
                            {
                                await page.EvaluateAsync("(el) => el.remove()", handle);
                                await page.WaitForTimeoutAsync(100);
                            }
                        }
                    }
                }
            }
            catch { /* swallow and retry next pass */
                    }

            // small settle between passes
            await page.WaitForTimeoutAsync(250);
        }
    }

    static async Task DebugDumpAsync(IPage page, string tag)
    {
        Directory.CreateDirectory("debug");
        var ts = DateTimeOffset.Now.ToString("yyyyMMdd_HHmmss");
        var png = Path.Combine("debug", $"{ts}_{tag}.png");
        var htmlPath = Path.Combine("debug", $"{ts}_{tag}.html");

        try
        {
            await page.ScreenshotAsync(new() { Path = png, FullPage = true });
        }
        catch { /* best effort */ }

        try
        {
            var html = await page.ContentAsync();
            await File.WriteAllTextAsync(htmlPath, html);
        }
        catch { /* best effort */ }

        // quick JS-side stats so you see *something* in console immediately
        var stats = await page.EvaluateAsync<Dictionary<string, int>>(@"
            (() => {
              const out = {};
              out.articles = document.querySelectorAll('article').length;
              out.linksAll = document.querySelectorAll('a').length;
              out.linksPosts = Array.from(document.querySelectorAll('a'))
                .filter(a => (a.href||'').match(/\/(posts|status|statuses)\//)).length;
              out.dialogs = document.querySelectorAll('[role=""dialog""], [aria-modal=""true""]').length;
              out.iframes = document.querySelectorAll('iframe').length;
              return out;
            })()");
        Console.WriteLine($"[DEBUG] Stats: " +
            $"articles={stats.GetValueOrDefault("articles")}, " +
            $"linksAll={stats.GetValueOrDefault("linksAll")}, " +
            $"linksPosts={stats.GetValueOrDefault("linksPosts")}, " +
            $"dialogs={stats.GetValueOrDefault("dialogs")}, " +
            $"iframes={stats.GetValueOrDefault("iframes")}");
        Console.WriteLine($"[DEBUG] Saved: {png}");
        Console.WriteLine($"[DEBUG] Saved: {htmlPath}");
    }

    static async Task SettleContentAsync(IPage page)
    {
        // Give the app time to render, then scroll to trigger lazy loads
        await page.WaitForTimeoutAsync(800);
        for (int i = 0; i < 4; i++)
        {
            await page.EvaluateAsync("window.scrollBy(0, Math.round(window.innerHeight*0.9));");
            await page.WaitForTimeoutAsync(350);
        }
        await page.EvaluateAsync("window.scrollTo(0, 0);"); // back to top
    }

    static async Task<List<PostRecord>> FallbackExtractPosts(IPage page, string username)
    {
        var raw = await page.EvaluateAsync<List<Dictionary<string, object?>>>(@$"
            (() => {{
              const out = [];
              const anchors = Array.from(document.querySelectorAll('a'))
                .filter(a => a.href && a.href.match(/\/(posts|status|statuses)\/[0-9A-Za-z\-]+/));
              const seen = new Set();

              for (const a of anchors) {{
                const url = a.href;
                const m = url.match(/(?:posts|status|statuses)\/([0-9A-Za-z\-]+)/);
                const id = m ? m[1] : url;
                if (seen.has(id)) continue; seen.add(id);

                // lightweight text: look within the closest article/div
                let root = a.closest('article') || a.closest('div');
                let text = '';
                if (root) {{
                  const clone = root.cloneNode(true);
                  clone.querySelectorAll('button, nav, svg, style, script').forEach(n => n.remove());
                  text = (clone.innerText || '').trim();
                }} else {{
                  text = (a.innerText || '').trim();
                }}

                // best-effort time
                let dt = null;
                const t = (root || a).querySelector?.('time[datetime]');
                if (t && t.getAttribute('datetime')) dt = t.getAttribute('datetime');

                out.push({{ id, url, text, dt }});
              }}
              return out;
            }})();
            ");

        var results = new List<PostRecord>();
        foreach (var r in raw)
        {
            var id = r.TryGetValue("id", out var idObj) ? idObj?.ToString() : null;
            var url = r.TryGetValue("url", out var uObj) ? uObj?.ToString() : null;
            var text = r.TryGetValue("text", out var tObj) ? (tObj?.ToString() ?? "").Trim() : "";
            var dt = r.TryGetValue("dt", out var dObj) ? dObj?.ToString() : null;

            if (string.IsNullOrWhiteSpace(id) || string.IsNullOrWhiteSpace(url)) continue;
            DateTimeOffset? when = null; if (DateTimeOffset.TryParse(dt, out var parsed)) when = parsed;
            results.Add(new PostRecord(id!, url!, username, text, when));
        }
        return results;
    }

    static async Task DismissTruthAdModal(IPage page)
    {
        // Short overall window so we don't hang
        var deadline = DateTime.UtcNow.AddSeconds(4);

        while (DateTime.UtcNow < deadline)
        {
            var closeBtn = page.Locator("button[data-testid='close-modal']");
            if (await closeBtn.IsVisibleAsync(new() { Timeout = 500 }))
            {
                await closeBtn.First.ClickAsync();
                // Wait until the modal root disappears or becomes hidden
                await page.Locator("[data-testid='modal-component']").WaitForAsync(new() { State = WaitForSelectorState.Detached, Timeout = 1500 });
                return;
            }

            // Fallbacks:
            await page.Keyboard.PressAsync("Escape");                 // many modals listen for ESC
            await page.WaitForTimeoutAsync(150);

            // Click the gray area (center of viewport) in case backdrop handles the close
            var vp = page.ViewportSize;               // PageViewportSizeResult?
            int w = vp?.Width ?? 1280;
            int h = vp?.Height ?? 720;
            await page.Mouse.ClickAsync(w / 2, h / 2);
            await page.WaitForTimeoutAsync(150);

            // If overlay is still present, loop again quickly
            var stillThere = await page.Locator("[data-testid='modal-component']").IsVisibleAsync(new() { Timeout = 300 });
            if (!stillThere) return;
        }
    }

}
